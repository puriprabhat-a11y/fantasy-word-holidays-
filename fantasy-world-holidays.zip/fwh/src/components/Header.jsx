import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Globe } from 'lucide-react';

const navLinks = [
  { label: 'Home',        href: '#' },
  { label: 'Packages',    href: '#packages' },
  { label: 'Destinations',href: '#destinations' },
  { label: 'Offers',      href: '#offers' },
  { label: 'Contact',     href: '#contact' },
];

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled]     = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white shadow-md' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2">
            <div className="w-9 h-9 gradient-primary rounded-lg flex items-center justify-center flex-shrink-0">
              <Globe className="h-5 w-5 text-white" />
            </div>
            <div className="leading-tight">
              <span className={`font-extrabold text-base ${scrolled ? 'text-gray-900' : 'text-white'}`}>
                Fantasy World
              </span>
              <span className={`block text-xs font-medium ${scrolled ? 'text-blue-600' : 'text-cyan-300'}`}>
                Holidays
              </span>
            </div>
          </a>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map(({ label, href }) => (
              <a
                key={label}
                href={href}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                  scrolled
                    ? 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
                    : 'text-white/90 hover:text-white hover:bg-white/10'
                }`}
              >
                {label}
              </a>
            ))}
          </nav>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <a
              href="tel:+911800123456"
              className={`flex items-center gap-1.5 text-sm font-medium ${
                scrolled ? 'text-gray-600 hover:text-blue-600' : 'text-white/90 hover:text-white'
              }`}
            >
              <Phone className="h-4 w-4" />
              1800-123-456
            </a>
            <button className="gradient-primary text-white text-sm font-semibold px-5 py-2 rounded-lg shadow-sm hover:shadow-md transition-all duration-200">
              Book Now
            </button>
          </div>

          {/* Mobile menu toggle */}
          <button
            className="md:hidden p-2 rounded-lg"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen
              ? <X className={`h-6 w-6 ${scrolled ? 'text-gray-700' : 'text-white'}`} />
              : <Menu className={`h-6 w-6 ${scrolled ? 'text-gray-700' : 'text-white'}`} />
            }
          </button>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 py-4 shadow-lg rounded-b-2xl">
            <nav className="flex flex-col gap-1 px-2 mb-4">
              {navLinks.map(({ label, href }) => (
                <a
                  key={label}
                  href={href}
                  onClick={() => setMobileOpen(false)}
                  className="px-4 py-2.5 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg text-sm font-medium transition-colors"
                >
                  {label}
                </a>
              ))}
            </nav>
            <div className="px-4 flex flex-col gap-2">
              <a href="tel:+911800123456" className="flex items-center gap-2 text-gray-600 text-sm">
                <Phone className="h-4 w-4" /> 1800-123-456
              </a>
              <button className="gradient-primary text-white text-sm font-semibold px-5 py-2.5 rounded-lg w-full">
                Book Now
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
