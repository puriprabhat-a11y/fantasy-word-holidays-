import React from 'react';
import { MapPin, ArrowRight } from 'lucide-react';
import { popularDestinations } from '../mockData';

const PopularDestinations = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="inline-block bg-cyan-100 text-cyan-700 text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wide mb-3">
            Top Picks
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
            Popular Destinations
          </h2>
          <p className="text-gray-600 text-lg">
            Explore the world's most sought-after travel destinations
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {popularDestinations.map((destination) => (
            <div
              key={destination.id}
              className="relative rounded-2xl overflow-hidden h-64 cursor-pointer card-hover group"
            >
              <img
                src={destination.image}
                alt={destination.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <div className="flex items-center text-white mb-1">
                  <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
                  <h3 className="font-bold text-lg leading-tight">{destination.name}</h3>
                </div>
                <p className="text-white/80 text-sm mb-2">{destination.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-cyan-300 font-bold text-base">{destination.price}</span>
                  <span className="flex items-center gap-1 text-white/80 text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    Explore <ArrowRight className="h-3 w-3" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PopularDestinations;
