import React from 'react';
import { Phone, Mail, MapPin, Globe, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer = () => {
  return (
    <footer id="contact" className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">

          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 gradient-primary rounded-lg flex items-center justify-center">
                <Globe className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-white font-extrabold text-base leading-tight">Fantasy World</p>
                <p className="text-cyan-400 text-xs font-medium">Holidays</p>
              </div>
            </div>
            <p className="text-sm leading-relaxed mb-5">
              Your trusted travel partner for unforgettable journeys. Serving travellers from Delhi since 2010.
            </p>
            <div className="flex gap-3">
              {[Facebook, Twitter, Instagram, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-8 h-8 bg-gray-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors duration-200"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold text-sm uppercase tracking-wider mb-4">Quick Links</h3>
            <ul className="space-y-2.5 text-sm">
              {['About Us', 'Careers', 'Blog', 'Press', 'Terms & Conditions', 'Privacy Policy'].map((item) => (
                <li key={item}>
                  <a href="#" className="hover:text-white hover:translate-x-1 inline-block transition-all duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white font-bold text-sm uppercase tracking-wider mb-4">Our Services</h3>
            <ul className="space-y-2.5 text-sm">
              {['Flight Booking', 'Hotel Booking', 'Train Tickets', 'Bus Booking', 'Holiday Packages', 'Visa Assistance', 'Travel Insurance'].map((item) => (
                <li key={item}>
                  <a href="#" className="hover:text-white hover:translate-x-1 inline-block transition-all duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-bold text-sm uppercase tracking-wider mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <Phone className="h-4 w-4 mt-0.5 text-cyan-400 flex-shrink-0" />
                <div>
                  <p className="text-white font-medium">+91 1800-123-4567</p>
                  <p className="text-xs text-gray-500">Mon–Sat, 9am–8pm</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="h-4 w-4 mt-0.5 text-cyan-400 flex-shrink-0" />
                <span>support@fantasyworldholidays.com</span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="h-4 w-4 mt-0.5 text-cyan-400 flex-shrink-0" />
                <span>Connaught Place, New Delhi — 110001</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-gray-500">
          <p>© 2025 Fantasy World Holidays. All rights reserved.</p>
          <p>Made with ❤️ in New Delhi, India</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
