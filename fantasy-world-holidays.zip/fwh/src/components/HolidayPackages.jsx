import React from 'react';
import { Clock, MapPin, Check, ArrowRight } from 'lucide-react';
import { holidayPackages } from '../mockData';

const HolidayPackages = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="inline-block bg-orange-100 text-orange-700 text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wide mb-3">
            Handpicked
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
            Featured Holiday Packages
          </h2>
          <p className="text-gray-600 text-lg">
            All-inclusive packages for your perfect vacation
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {holidayPackages.map((pkg) => (
            <div
              key={pkg.id}
              className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 card-hover group"
            >
              {/* Image */}
              <div className="relative h-56 overflow-hidden">
                <img
                  src={pkg.image}
                  alt={pkg.destination}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                {/* Price badge */}
                <div className="absolute top-4 left-4 bg-white rounded-xl shadow-lg px-3 py-2">
                  <p className="text-xl font-extrabold text-blue-600">{pkg.price}</p>
                  <p className="text-xs text-gray-500">per person</p>
                </div>
              </div>

              {/* Body */}
              <div className="p-6">
                <div className="flex items-center gap-2 text-gray-800 mb-1">
                  <MapPin className="h-4 w-4 text-blue-500 flex-shrink-0" />
                  <h3 className="font-bold text-lg">{pkg.destination}</h3>
                </div>
                <div className="flex items-center gap-2 text-gray-500 mb-4">
                  <Clock className="h-4 w-4 flex-shrink-0" />
                  <span className="text-sm">{pkg.duration}</span>
                </div>

                {/* Inclusions */}
                <div className="mb-5">
                  <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
                    What's included
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {pkg.inclusions.map((item, i) => (
                      <span
                        key={i}
                        className="flex items-center gap-1 bg-green-50 text-green-700 text-xs font-medium px-2.5 py-1 rounded-full"
                      >
                        <Check className="h-3 w-3" />
                        {item}
                      </span>
                    ))}
                  </div>
                </div>

                {/* CTA */}
                <button className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white font-semibold py-3 rounded-xl transition-all duration-200 shadow-sm hover:shadow-md">
                  View Details
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HolidayPackages;
