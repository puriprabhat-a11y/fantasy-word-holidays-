import React, { useState } from 'react';
import { ArrowRightLeft, Search } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { toast } from './ui/sonner';

const FlightSearch = () => {
  const [tripType, setTripType]     = useState('roundTrip');
  const [from, setFrom]             = useState('');
  const [to, setTo]                 = useState('');
  const [departDate, setDepartDate] = useState('');
  const [returnDate, setReturnDate] = useState('');
  const [travelers, setTravelers]   = useState('1');
  const [classType, setClassType]   = useState('economy');

  const handleSearch = () => {
    if (!from || !to || !departDate) {
      toast.error('Please fill all required fields');
      return;
    }
    toast.success('Searching for flights...');
  };

  const swapCities = () => {
    const temp = from;
    setFrom(to);
    setTo(temp);
  };

  return (
    <div className="space-y-6">
      {/* Trip type */}
      <RadioGroup value={tripType} onValueChange={setTripType} className="flex gap-6">
        {[
          { value: 'roundTrip', label: 'Round Trip' },
          { value: 'oneWay',    label: 'One Way'    },
          { value: 'multiCity', label: 'Multi City' },
        ].map(({ value, label }) => (
          <div key={value} className="flex items-center gap-2">
            <RadioGroupItem value={value} id={value} />
            <Label htmlFor={value} className="cursor-pointer">{label}</Label>
          </div>
        ))}
      </RadioGroup>

      {/* Row 1 */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        <div className="md:col-span-3">
          <Label htmlFor="from" className="mb-1.5 block">From</Label>
          <Input id="from" placeholder="City or airport" value={from} onChange={(e) => setFrom(e.target.value)} className="h-12" />
        </div>

        <div className="md:col-span-1 flex items-end justify-center">
          <Button variant="outline" size="icon" onClick={swapCities} className="h-12 w-12 rounded-full hover:bg-blue-50">
            <ArrowRightLeft className="h-5 w-5 text-blue-600" />
          </Button>
        </div>

        <div className="md:col-span-3">
          <Label htmlFor="to" className="mb-1.5 block">To</Label>
          <Input id="to" placeholder="City or airport" value={to} onChange={(e) => setTo(e.target.value)} className="h-12" />
        </div>

        <div className="md:col-span-2">
          <Label htmlFor="departDate" className="mb-1.5 block">Departure</Label>
          <Input id="departDate" type="date" value={departDate} onChange={(e) => setDepartDate(e.target.value)} className="h-12" />
        </div>

        {tripType === 'roundTrip' && (
          <div className="md:col-span-2">
            <Label htmlFor="returnDate" className="mb-1.5 block">Return</Label>
            <Input id="returnDate" type="date" value={returnDate} onChange={(e) => setReturnDate(e.target.value)} className="h-12" />
          </div>
        )}
      </div>

      {/* Row 2 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="travelers" className="mb-1.5 block">Travelers</Label>
          <Input id="travelers" type="number" min="1" max="9" value={travelers} onChange={(e) => setTravelers(e.target.value)} className="h-12" />
        </div>
        <div>
          <Label htmlFor="class" className="mb-1.5 block">Class</Label>
          <select
            id="class"
            value={classType}
            onChange={(e) => setClassType(e.target.value)}
            className="w-full h-12 px-3 rounded-lg border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="economy">Economy</option>
            <option value="premiumEconomy">Premium Economy</option>
            <option value="business">Business</option>
            <option value="firstClass">First Class</option>
          </select>
        </div>
      </div>

      {/* Search button */}
      <div className="flex justify-center pt-2">
        <Button
          onClick={handleSearch}
          className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white px-12 py-3 text-base font-semibold rounded-xl shadow-md hover:shadow-lg transition-all duration-300"
        >
          <Search className="h-5 w-5 mr-2" />
          Search Flights
        </Button>
      </div>
    </div>
  );
};

export default FlightSearch;
