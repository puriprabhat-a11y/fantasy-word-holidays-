import React, { useState, useEffect, createContext, useContext, useCallback } from 'react';

const ToastContext = createContext(null);

let toastFn = null;

export const toast = {
  success: (msg) => toastFn && toastFn({ message: msg, type: 'success' }),
  error: (msg) => toastFn && toastFn({ message: msg, type: 'error' }),
  info: (msg) => toastFn && toastFn({ message: msg, type: 'info' }),
};

export const Toaster = ({ position = 'top-right' }) => {
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    toastFn = ({ message, type }) => {
      const id = Date.now();
      setToasts((prev) => [...prev, { id, message, type }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 3500);
    };
    return () => { toastFn = null; };
  }, []);

  const positionClasses = {
    'top-right': 'top-4 right-4',
    'top-left': 'top-4 left-4',
    'bottom-right': 'bottom-4 right-4',
    'bottom-left': 'bottom-4 left-4',
  };

  const typeClasses = {
    success: 'bg-green-600',
    error: 'bg-red-600',
    info: 'bg-blue-600',
  };

  return (
    <div className={`fixed ${positionClasses[position] || positionClasses['top-right']} z-50 flex flex-col gap-2`}>
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`${typeClasses[t.type] || typeClasses.info} text-white px-4 py-3 rounded-lg shadow-lg text-sm font-medium min-w-[220px] animate-fade-in`}
        >
          {t.message}
        </div>
      ))}
    </div>
  );
};
