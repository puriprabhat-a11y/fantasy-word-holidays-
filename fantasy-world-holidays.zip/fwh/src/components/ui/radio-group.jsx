import React from 'react';

export const RadioGroup = ({ children, value, onValueChange, className = '' }) => {
  return (
    <div className={className} role="radiogroup">
      {React.Children.map(children, (child) =>
        React.cloneElement(child, { selectedValue: value, onValueChange })
      )}
    </div>
  );
};

export const RadioGroupItem = ({ value, id, selectedValue, onValueChange }) => {
  return (
    <input
      type="radio"
      id={id}
      value={value}
      checked={selectedValue === value}
      onChange={() => onValueChange && onValueChange(value)}
      className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
    />
  );
};
