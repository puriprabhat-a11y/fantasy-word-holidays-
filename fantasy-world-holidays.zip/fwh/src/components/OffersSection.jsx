import React, { useState } from 'react';
import { Tag, Copy, Check } from 'lucide-react';
import { offers } from '../mockData';

const OffersSection = () => {
  const [copiedId, setCopiedId] = useState(null);

  const handleCopy = (code, id) => {
    navigator.clipboard.writeText(code).catch(() => {});
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <section className="py-16 bg-gradient-to-br from-blue-50 to-cyan-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="inline-block bg-blue-100 text-blue-700 text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wide mb-3">
            Limited Time Deals
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
            Exclusive Offers & Discounts
          </h2>
          <p className="text-gray-600 text-lg">
            Grab these deals before they expire
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {offers.map((offer) => (
            <div
              key={offer.id}
              className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 card-hover"
            >
              {/* Image */}
              <div className="relative h-40 overflow-hidden">
                <img
                  src={offer.image}
                  alt={offer.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <span className="absolute bottom-3 left-3 bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded-lg">
                  Valid till {offer.validTill}
                </span>
              </div>

              {/* Content */}
              <div className="p-4">
                <h3 className="font-bold text-gray-900 mb-1 text-sm leading-snug">
                  {offer.title}
                </h3>
                <p className="text-gray-500 text-xs mb-3">{offer.description}</p>

                {/* Coupon code */}
                <div className="flex items-center justify-between bg-blue-50 border border-dashed border-blue-300 rounded-lg px-3 py-2">
                  <div className="flex items-center gap-1.5">
                    <Tag className="h-3.5 w-3.5 text-blue-500" />
                    <span className="text-blue-700 font-bold text-sm tracking-wider">
                      {offer.code}
                    </span>
                  </div>
                  <button
                    onClick={() => handleCopy(offer.code, offer.id)}
                    className="text-blue-600 hover:text-blue-800 transition-colors"
                    title="Copy code"
                  >
                    {copiedId === offer.id
                      ? <Check className="h-4 w-4 text-green-500" />
                      : <Copy className="h-4 w-4" />
                    }
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default OffersSection;
