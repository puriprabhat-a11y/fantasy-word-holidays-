import React, { useState } from 'react';
import { Plane, Hotel, Train, Bus, Package } from 'lucide-react';
import FlightSearch from './FlightSearch';
import HotelSearch from './HotelSearch';
import TrainSearch from './TrainSearch';
import BusSearch from './BusSearch';
import HolidaySearch from './HolidaySearch';
import { Toaster } from './ui/sonner';

const tabs = [
  { id: 'flights',  label: 'Flights',  Icon: Plane    },
  { id: 'hotels',   label: 'Hotels',   Icon: Hotel    },
  { id: 'trains',   label: 'Trains',   Icon: Train    },
  { id: 'buses',    label: 'Buses',    Icon: Bus      },
  { id: 'holidays', label: 'Holidays', Icon: Package  },
];

const SearchSection = () => {
  const [activeTab, setActiveTab] = useState('flights');

  const renderSearch = () => {
    switch (activeTab) {
      case 'flights':  return <FlightSearch />;
      case 'hotels':   return <HotelSearch />;
      case 'trains':   return <TrainSearch />;
      case 'buses':    return <BusSearch />;
      case 'holidays': return <HolidaySearch />;
      default:         return <FlightSearch />;
    }
  };

  return (
    <section className="relative gradient-hero py-20 px-4">
      <Toaster position="top-right" />

      {/* Background overlay */}
      <div className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1488085061387-422e29b40080?w=1600&q=80)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      <div className="relative max-w-6xl mx-auto">
        {/* Hero headline */}
        <div className="text-center mb-10">
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4 leading-tight">
            Explore the World with
            <span className="block text-cyan-400">Fantasy World Holidays</span>
          </h1>
          <p className="text-blue-100 text-lg max-w-xl mx-auto">
            Flights, hotels, trains, buses & holiday packages — all in one place
          </p>
        </div>

        {/* Search card */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          {/* Tabs */}
          <div className="flex overflow-x-auto border-b border-gray-100 bg-gray-50">
            {tabs.map(({ id, label, Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`flex items-center gap-2 px-6 py-4 text-sm font-semibold whitespace-nowrap transition-all duration-200 border-b-2
                  ${activeTab === id
                    ? 'border-blue-600 text-blue-600 bg-white'
                    : 'border-transparent text-gray-500 hover:text-blue-600 hover:bg-white'
                  }`}
              >
                <Icon className="h-4 w-4" />
                {label}
              </button>
            ))}
          </div>

          {/* Search form */}
          <div className="p-6 md:p-8">
            {renderSearch()}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SearchSection;
