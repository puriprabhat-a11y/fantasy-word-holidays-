import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { toast } from './ui/sonner';

const HolidaySearch = () => {
  const [destination, setDestination] = useState('');
  const [startDate, setStartDate]     = useState('');
  const [duration, setDuration]       = useState('3');
  const [travelers, setTravelers]     = useState('2');
  const [packageType, setPackageType] = useState('all');

  const handleSearch = () => {
    if (!destination || !startDate) {
      toast.error('Please fill all required fields');
      return;
    }
    toast.success('Searching for holiday packages...');
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        <div className="md:col-span-4">
          <Label htmlFor="destination" className="mb-1.5 block">Destination</Label>
          <Input id="destination" placeholder="Where do you want to go?" value={destination} onChange={(e) => setDestination(e.target.value)} className="h-12" />
        </div>
        <div className="md:col-span-3">
          <Label htmlFor="startDate" className="mb-1.5 block">Start Date</Label>
          <Input id="startDate" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="h-12" />
        </div>
        <div className="md:col-span-2">
          <Label htmlFor="duration" className="mb-1.5 block">Duration (Days)</Label>
          <Input id="duration" type="number" min="1" max="30" value={duration} onChange={(e) => setDuration(e.target.value)} className="h-12" />
        </div>
        <div className="md:col-span-3">
          <Label htmlFor="holidayTravelers" className="mb-1.5 block">Travelers</Label>
          <Input id="holidayTravelers" type="number" min="1" max="20" value={travelers} onChange={(e) => setTravelers(e.target.value)} className="h-12" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="packageType" className="mb-1.5 block">Package Type</Label>
          <select
            id="packageType"
            value={packageType}
            onChange={(e) => setPackageType(e.target.value)}
            className="w-full h-12 px-3 rounded-lg border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Packages</option>
            <option value="beach">Beach Holiday</option>
            <option value="adventure">Adventure</option>
            <option value="cultural">Cultural Tour</option>
            <option value="luxury">Luxury Getaway</option>
            <option value="family">Family Package</option>
            <option value="honeymoon">Honeymoon Special</option>
          </select>
        </div>
      </div>

      <div className="flex justify-center pt-2">
        <Button onClick={handleSearch} className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white px-12 py-3 text-base font-semibold rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
          <Search className="h-5 w-5 mr-2" />
          Search Packages
        </Button>
      </div>
    </div>
  );
};

export default HolidaySearch;
