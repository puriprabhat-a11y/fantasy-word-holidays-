import React from 'react';
import Header from '../components/Header';
import SearchSection from '../components/SearchSection';
import OffersSection from '../components/OffersSection';
import HolidayPackages from '../components/HolidayPackages';
import PopularDestinations from '../components/PopularDestinations';
import FeaturesSection from '../components/FeaturesSection';
import Footer from '../components/Footer';

const HomePage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main>
        {/* Hero + Search */}
        <SearchSection />

        {/* Offers & Deals */}
        <section id="offers">
          <OffersSection />
        </section>

        {/* Holiday Packages */}
        <section id="packages">
          <HolidayPackages />
        </section>

        {/* Popular Destinations */}
        <section id="destinations">
          <PopularDestinations />
        </section>

        {/* Why Choose Us */}
        <FeaturesSection />

        {/* Download App Banner */}
        <section className="gradient-primary py-14">
          <div className="max-w-4xl mx-auto px-4 text-center text-white">
            <h2 className="text-3xl font-extrabold mb-3">
              Travel Smarter with Our App
            </h2>
            <p className="text-blue-100 mb-8 text-lg">
              Exclusive mobile deals, instant bookings, real-time alerts
            </p>
            <div className="flex justify-center gap-4 flex-wrap">
              <button className="flex items-center gap-2 bg-white text-blue-600 font-bold px-7 py-3 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-0.5">
                <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                </svg>
                App Store
              </button>
              <button className="flex items-center gap-2 bg-white text-blue-600 font-bold px-7 py-3 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-0.5">
                <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M3.18 23.76c.3.17.66.19.99.07l12.45-7.17-2.78-2.79-10.66 9.89zM.54 1.06C.2 1.4 0 1.96 0 2.7v18.6c0 .74.2 1.3.55 1.64l.09.08 10.42-10.43v-.24L.63.98l-.09.08zM20.47 10.5l-2.78-1.6-3.11 3.12 3.11 3.1 2.8-1.61c.8-.46.8-1.54-.02-2zM3.18.24L15.64 7.4l-2.78 2.78L2.19.17c.33-.12.69-.1.99.07z"/>
                </svg>
                Google Play
              </button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default HomePage;
